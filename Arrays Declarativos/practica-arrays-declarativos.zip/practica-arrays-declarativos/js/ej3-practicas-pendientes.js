    // Ejercicio 3 - Prácticas no entregadas
// Usa exclusivamente métodos declarativos de arrays (map, filter, reduce, some, every, find, sort, forEach).
    // No utilices bucles for ni while.

    const alumnos = [
  { id: 1, nombre: 'Laura', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 8.2, faltas: 2, practicasEntregadas: 6, practicasTotales: 6, repetidor: false },
  { id: 2, nombre: 'Diego', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 4.7, faltas: 7, practicasEntregadas: 4, practicasTotales: 6, repetidor: false },
  { id: 3, nombre: 'Marta', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 6.5, faltas: 1, practicasEntregadas: 6, practicasTotales: 6, repetidor: true },
  { id: 4, nombre: 'Pablo', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 5.1, faltas: 5, practicasEntregadas: 5, practicasTotales: 6, repetidor: false },
  { id: 5, nombre: 'Alae', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 9.0, faltas: 0, practicasEntregadas: 6, practicasTotales: 6, repetidor: false },
  { id: 6, nombre: 'Naaman', grupo: '1ºDAW', modulo: 'DIW', notaMedia: 3.9, faltas: 8, practicasEntregadas: 3, practicasTotales: 6, repetidor: true }
];


    // Escribe aquí tu solución para este ejercicio.
    // Recuerda probar el archivo activando su <script> correspondiente en index.html
    // y comprobando los resultados en la consola del navegador.
