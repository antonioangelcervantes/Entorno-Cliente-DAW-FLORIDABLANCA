// TODO: Los alumnos deben completar este código

// 1. Obtener referencias a los elementos HTML
const tareaInput = document. getElementById('tareaInput');
const agregarBtn = document.getElementById('agregarBtn');
const listaTareas = document.getElementById('listaTareas');
const limpiarBtn = document.getElementById('limpiarBtn');

// 2. Función para cargar tareas desde LocalStorage
function cargarTareas() {
    // TODO: 
    // - Obtener las tareas del localStorage con la clave 'tareas'
    // - Si no hay tareas, devolver un array vacío
    // - Recuerda usar JSON.parse() para convertir el texto a array
    
}

// 3. Función para guardar tareas en LocalStorage
function guardarTareas(tareas) {
    // TODO: 
    // - Convertir el array de tareas a texto con JSON.stringify()
    // - Guardar en localStorage con la clave 'tareas'
    
}

// 4. Función para mostrar las tareas en la página
function mostrarTareas() {
    // TODO:
    // - Limpiar la lista actual (listaTareas. innerHTML = '')
    // - Cargar las tareas
    // - Recorrer cada tarea y crear un elemento <li>
    // - Agregar un botón de eliminar a cada tarea
    
}

// 5. Función para agregar una nueva tarea
function agregarTarea() {
    // TODO:
    // - Obtener el valor del input
    // - Validar que no esté vacío
    // - Cargar las tareas existentes
    // - Agregar la nueva tarea al array
    // - Guardar el array actualizado
    // - Mostrar las tareas
    // - Limpiar el input
    
}

// 6. Función para eliminar una tarea
function eliminarTarea(indice) {
    // TODO:
    // - Cargar las tareas
    // - Eliminar la tarea en el índice dado (usar splice)
    // - Guardar las tareas actualizadas
    // - Mostrar las tareas
    
}

// 7. Función para limpiar todas las tareas
function limpiarTodo() {
    // TODO:
    // - Usar localStorage.removeItem('tareas') o localStorage.clear()
    // - Mostrar las tareas (la lista quedará vacía)
    
}

// 8. Event Listeners
agregarBtn.addEventListener('click', agregarTarea);
tareaInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') agregarTarea();
});
limpiarBtn.addEventListener('click', limpiarTodo);

// 9. Cargar tareas al iniciar la página
mostrarTareas();